package com.example.android.note_keeper;

public class NoteRecyclerAdapter {
}
